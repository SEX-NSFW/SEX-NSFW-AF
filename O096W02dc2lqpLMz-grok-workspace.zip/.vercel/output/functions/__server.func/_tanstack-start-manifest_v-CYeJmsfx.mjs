//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CYeJmsfx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/cover",
			"/api/image"
		],
		preloads: ["/assets/index-COmI6CMf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-COmI6CMf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D6e72cOm.js"]
	}
} });
//#endregion
export { tsrStartManifest };
