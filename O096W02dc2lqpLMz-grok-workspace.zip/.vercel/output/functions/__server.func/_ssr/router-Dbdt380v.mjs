import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dbdt380v.js
var router_Dbdt380v_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-CCkssDAy.css";
var APP_NAME = "SceneCover";
var Route$3 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "From title to official cover"
			},
			{
				name: "theme-color",
				content: "#0c0b0a"
			},
			{
				name: "rating",
				content: "adult"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter = () => import("./routes-ce89efAF.mjs");
var Route$2 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var FETCH_HEADERS = {
	"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
	Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
	"Accept-Language": "en-US,en;q=0.9"
};
var IMAGE_HOSTS = /* @__PURE__ */ new Set([
	"cdn.porndiff.com",
	"en.porndiff.com",
	"porndiff.com",
	"images.psmcdn.net",
	"static.thenude.com",
	"www.thenude.com",
	"brattyfamily.com",
	"www.brattyfamily.com"
]);
function isAllowedImageUrl(raw) {
	try {
		const u = new URL(raw);
		if (u.protocol !== "https:") return false;
		if (!IMAGE_HOSTS.has(u.hostname)) return false;
		return /\.(jpe?g|png|webp|gif)(\?|$)/i.test(u.pathname) || u.hostname.includes("psmcdn") || u.pathname.includes("/tubes/") || u.pathname.includes("/covers/");
	} catch {
		return false;
	}
}
function isImageMagic(buf) {
	if (buf.length < 4) return false;
	if (buf[0] === 255 && buf[1] === 216 && buf[2] === 255) return true;
	if (buf[0] === 137 && buf[1] === 80 && buf[2] === 78 && buf[3] === 71) return true;
	if (buf[0] === 71 && buf[1] === 73 && buf[2] === 70) return true;
	if (buf[0] === 82 && buf[1] === 73 && buf[2] === 70 && buf[3] === 70 && buf.length >= 12 && buf[8] === 87 && buf[9] === 69 && buf[10] === 66 && buf[11] === 80) return true;
	return false;
}
async function fetchHtml(url, timeoutMs = 12e3) {
	try {
		const res = await fetch(url, {
			headers: FETCH_HEADERS,
			redirect: "follow",
			signal: AbortSignal.timeout(timeoutMs)
		});
		if (!res.ok) return null;
		const ct = (res.headers.get("content-type") || "").toLowerCase();
		if (ct && !ct.includes("html") && !ct.includes("xml") && !ct.includes("text/")) return null;
		return await res.text();
	} catch {
		return null;
	}
}
async function verifyImage(url) {
	if (!isAllowedImageUrl(url)) return null;
	try {
		const res = await fetch(url, {
			method: "GET",
			headers: {
				...FETCH_HEADERS,
				Accept: "image/jpeg,image/png,image/webp,image/*;q=0.8,*/*;q=0.5",
				Range: "bytes=0-63"
			},
			redirect: "follow",
			signal: AbortSignal.timeout(8e3)
		});
		if (!res.ok && res.status !== 206) return null;
		const ct = (res.headers.get("content-type") || "").toLowerCase();
		if (ct.includes("text/html") || ct.includes("application/json")) return null;
		if (!isImageMagic(new Uint8Array(await res.arrayBuffer()))) return null;
		return url;
	} catch {
		return null;
	}
}
function unwrapPsmcdn(url) {
	const cgi = url.match(/https:\/\/images\.psmcdn\.net\/cdn-cgi\/image\/[^/]+\/(teamskeet\/[^?#]+)/i);
	if (cgi?.[1]) return `https://images.psmcdn.net/${cgi[1]}`;
	return url;
}
function preferHiJpg(url) {
	return unwrapPsmcdn(url).replace(/\/shared\/(med|low|thumb)\.jpg/i, "/shared/hi.jpg");
}
function toCdnPorndiff(url) {
	return url.replace("https://en.porndiff.com/tubes/", "https://cdn.porndiff.com/tubes/");
}
function attr(html, name) {
	const re = new RegExp(`<meta[^>]+(?:property|name)=["']${name}["'][^>]*content=["']([^"']+)["']`, "i");
	const re2 = new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']${name}["']`, "i");
	return re.exec(html)?.[1] ?? re2.exec(html)?.[1] ?? null;
}
var STOP = /* @__PURE__ */ new Set([
	"a",
	"an",
	"the",
	"of",
	"and",
	"or",
	"to",
	"in",
	"on",
	"for",
	"with",
	"my",
	"her",
	"his",
	"she",
	"he",
	"is",
	"from",
	"by",
	"at",
	"as",
	"it",
	"this",
	"that",
	"video",
	"scene",
	"porn",
	"xxx",
	"official",
	"hd",
	"com",
	"www",
	"watch",
	"full",
	"free",
	"starring",
	"feat",
	"featuring"
]);
var STUDIO_ALIASES = [
	{
		keys: [
			"family strokes",
			"familystrokes",
			"family-strokes"
		],
		name: "Family Strokes",
		code: "fs",
		host: "www.familystrokes.com"
	},
	{
		keys: [
			"perv mom",
			"pervmom",
			"perv-mom"
		],
		name: "PervMom",
		code: "pvm",
		host: "www.pervmom.com"
	},
	{
		keys: [
			"sis loves me",
			"sislovesme",
			"sis-loves-me"
		],
		name: "SisLovesMe",
		code: "slm",
		host: "www.sislovesme.com"
	},
	{
		keys: [
			"dad crush",
			"dadcrush",
			"dad-crush"
		],
		name: "DadCrush",
		code: "dc",
		host: "www.dadcrush.com"
	},
	{
		keys: [
			"mom is horny",
			"momishorny",
			"mom-is-horny"
		],
		name: "MomIsHorny",
		code: "mih",
		host: "www.momishorny.com"
	},
	{
		keys: [
			"bratty sis",
			"brattysis",
			"bratty sis.com",
			"brattysis.com"
		],
		name: "Bratty Sis",
		thenude: "brattysis"
	},
	{
		keys: [
			"moms teach sex",
			"momsteachsex",
			"mom teach sex"
		],
		name: "Moms Teach Sex",
		thenude: "momsteachsex"
	},
	{
		keys: [
			"nubiles porn",
			"nubiles-porn",
			"nubilesporn",
			"nubiles"
		],
		name: "Nubiles",
		thenude: "nubiles"
	},
	{
		keys: ["brazzers"],
		name: "Brazzers",
		thenude: "brazzers"
	},
	{
		keys: ["team skeet", "teamskeet"],
		name: "TeamSkeet"
	}
];
var STUDIO_PREFIXES = [
	{
		prefix: "brattysis-",
		name: "Bratty Sis"
	},
	{
		prefix: "nubilesporn-",
		name: "Nubiles"
	},
	{
		prefix: "brazzers-",
		name: "Brazzers"
	},
	{
		prefix: "bangbros-",
		name: "BangBros"
	},
	{
		prefix: "reality-kings-",
		name: "Reality Kings"
	},
	{
		prefix: "girlsway-",
		name: "Girlsway"
	},
	{
		prefix: "kink-",
		name: "Kink"
	},
	{
		prefix: "mofos-",
		name: "Mofos"
	},
	{
		prefix: "tushy-",
		name: "Tushy"
	},
	{
		prefix: "blacked-",
		name: "Blacked"
	},
	{
		prefix: "vixen-",
		name: "Vixen"
	},
	{
		prefix: "puretaboo-",
		name: "Pure Taboo"
	},
	{
		prefix: "familysinners-",
		name: "Family Sinners"
	}
];
function decodeHtml(input) {
	return input.replace(/&nbsp;/gi, " ").replace(/&/gi, "&").replace(/"/gi, "\"").replace(/'/gi, "'").replace(/&#0*39;/g, "'").replace(/&#x27;/gi, "'").replace(/</gi, "<").replace(/>/gi, ">").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)));
}
function detectStudios(query) {
	const n = normalizeTitle(query);
	return STUDIO_ALIASES.filter((s) => s.keys.some((k) => n.includes(k)));
}
function stripStudios(text) {
	let n = normalizeTitle(text);
	const keys = STUDIO_ALIASES.flatMap((s) => s.keys).sort((a, b) => b.length - a.length);
	for (const key of keys) n = n.replaceAll(key, " ");
	return n.replace(/\s+/g, " ").trim();
}
function studioFromSlug(slug) {
	const lower = slug.toLowerCase();
	for (const { prefix, name } of STUDIO_PREFIXES) if (lower.startsWith(prefix)) return name;
	return null;
}
function normalizeTitle(s) {
	let t = decodeHtml(s).toLowerCase();
	t = t.replace(/[’'`]/g, "");
	t = t.replace(/s(\d+)\s*[:\-.]?\s*e(\d+)/gi, " s$1 e$2 ");
	t = t.replace(/\bstep[\s-]*mom\b/g, "stepmom");
	t = t.replace(/\bstep[\s-]*mother\b/g, "stepmom");
	t = t.replace(/\bstep[\s-]*daughter\b/g, "stepdaughter");
	t = t.replace(/\bstep[\s-]*sister\b/g, "stepsister");
	t = t.replace(/\bstep[\s-]*bro(?:ther)?\b/g, "stepbrother");
	t = t.replace(/\bstep[\s-]*dad\b/g, "stepdad");
	t = t.replace(/\bstep[\s-]*father\b/g, "stepdad");
	t = t.replace(/[^a-z0-9]+/g, " ");
	return t.replace(/\s+/g, " ").trim();
}
function meaningfulTokens(s) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const w of normalizeTitle(s).split(" ")) {
		if (w.length < 2 || STOP.has(w) || seen.has(w)) continue;
		seen.add(w);
		out.push(w);
	}
	return out;
}
function isStrongMatch(query, title, extra = "") {
	const qExact = stripStudios(query);
	const tExact = stripStudios(title);
	if (!qExact || !tExact) return {
		ok: false,
		score: 0,
		overlap: 0
	};
	if (qExact === tExact) return {
		ok: true,
		score: 100,
		overlap: meaningfulTokens(qExact).length
	};
	const qt = meaningfulTokens(qExact);
	const tt = meaningfulTokens(`${tExact} ${extra}`);
	const overlap = qt.filter((tok) => tt.includes(tok));
	const union = /* @__PURE__ */ new Set([...qt, ...tt]);
	const jaccard = union.size ? overlap.length / union.size : 0;
	if (overlap.length >= 3) {
		const extraPenalty = Math.max(0, tt.length - overlap.length) * 1.5;
		return {
			ok: true,
			score: 40 + overlap.length * 8 + jaccard * 20 - extraPenalty,
			overlap: overlap.length
		};
	}
	return {
		ok: false,
		score: overlap.length + jaccard,
		overlap: overlap.length
	};
}
function slugifyTitle(title) {
	const base = stripStudios(title).replace(/s(\d+)\s+e(\d+)/g, "s$1-e$2").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
	const variants = /* @__PURE__ */ new Set();
	if (base) variants.add(base);
	const collapsed = base.replace(/step-mom/g, "stepmom").replace(/step-daughter/g, "stepdaughter").replace(/step-sister/g, "stepsister");
	if (collapsed) variants.add(collapsed);
	const expanded = base.replace(/stepmom/g, "step-mom").replace(/stepdaughter/g, "step-daughter").replace(/stepsister/g, "step-sister");
	if (expanded) variants.add(expanded);
	return [...variants];
}
function pickBestMatch(items, query, getTitle, getExtra) {
	let best = null;
	for (const item of items) {
		const match = isStrongMatch(query, getTitle(item), getExtra ? getExtra(item) : "");
		if (!match.ok) continue;
		if (!best || match.score > best.match.score) best = {
			item,
			match
		};
	}
	return best;
}
var CODE_STUDIO = {
	fs: "Family Strokes",
	pvm: "PervMom",
	slm: "SisLovesMe",
	dc: "DadCrush",
	mih: "MomIsHorny"
};
function empty(error) {
	return {
		coverUrl: null,
		title: null,
		studio: null,
		source: null,
		performers: [],
		pageUrl: null,
		error
	};
}
async function firstVerified(urls) {
	const seen = /* @__PURE__ */ new Set();
	for (const raw of urls) {
		if (!raw) continue;
		const url = raw.replace(/\\/g, "").trim();
		if (!url.startsWith("https://") || seen.has(url)) continue;
		seen.add(url);
		const ok = await verifyImage(url);
		if (ok) return ok;
	}
	return null;
}
function parsePorndiffSearch(html) {
	const hits = [];
	const re = /<a href="(https:\/\/(?:en\.)?porndiff\.com\/videos\/([^"]+))"\s+title="([^"]*)"[^>]*class="font-medium leading-5 font-title[^"]*"[^>]*>([^<]+)<\/a>/g;
	let m;
	while (m = re.exec(html)) {
		const pageUrl = m[1].replace("https://porndiff.com/", "https://en.porndiff.com/");
		const slug = m[2];
		const title = decodeHtml(m[4] || m[3] || "");
		const windowStart = Math.max(0, m.index - 3500);
		const windowEnd = Math.min(html.length, m.index + 1800);
		const around = html.slice(windowStart, windowEnd);
		const posterMatch = around.match(/https:\\\/\\\/cdn\.porndiff\.com\\\/tubes\\\/[^"'\\\s]+\.(?:jpg|jpeg|png|webp)/i) || around.match(/https:\/\/cdn\.porndiff\.com\/tubes\/[^"'\s]+\.(?:jpg|jpeg|png|webp)/i);
		const poster = posterMatch ? posterMatch[0].replace(/\\\//g, "/") : `https://cdn.porndiff.com/tubes/${slug}_poster_01.jpg`;
		const performers = [...around.matchAll(/href="https:\/\/en\.porndiff\.com\/actors\/[^"]+"[^>]*>([^<]+)<\/a>/g)].map((x) => decodeHtml(x[1].trim()));
		hits.push({
			slug,
			title,
			poster,
			performers: [...new Set(performers)].slice(0, 8),
			pageUrl
		});
	}
	if (!hits.length) {
		const loose = /href="https:\/\/(?:en\.)?porndiff\.com\/videos\/([^"]+)"[^>]*>([^<]+)<\/a>/g;
		const seen = /* @__PURE__ */ new Set();
		let n;
		while (n = loose.exec(html)) {
			const slug = n[1];
			if (seen.has(slug)) continue;
			seen.add(slug);
			hits.push({
				slug,
				title: decodeHtml(n[2]),
				poster: `https://cdn.porndiff.com/tubes/${slug}_poster_01.jpg`,
				performers: [],
				pageUrl: `https://en.porndiff.com/videos/${slug}`
			});
		}
	}
	return hits;
}
async function enrichPorndiff(hit) {
	const candidates = [];
	if (hit.poster) candidates.push(toCdnPorndiff(hit.poster));
	candidates.push(`https://cdn.porndiff.com/tubes/${hit.slug}_poster_01.jpg`);
	candidates.push(`https://cdn.porndiff.com/tubes/${hit.slug}.jpg`);
	const html = await fetchHtml(hit.pageUrl, 1e4);
	if (!html) return {
		studio: studioFromSlug(hit.slug),
		coverCandidates: candidates,
		title: hit.title
	};
	const og = attr(html, "og:image");
	if (og) candidates.unshift(toCdnPorndiff(og));
	const cdn = html.match(/https:\/\/cdn\.porndiff\.com\/tubes\/[^"'\\\s>]+\.(?:jpg|jpeg|png|webp)/i);
	if (cdn) candidates.unshift(cdn[0].replace(/\\\//g, "/"));
	let studio = studioFromSlug(hit.slug);
	const company = html.match(/"productionCompany"\s*:\s*\{[^}]*"name"\s*:\s*"([^"]+)"/);
	if (company) studio = decodeHtml(company[1]);
	const ogTitle = attr(html, "og:title");
	return {
		studio,
		coverCandidates: candidates,
		title: ogTitle ? decodeHtml(ogTitle) : hit.title
	};
}
async function searchPorndiff(query) {
	const html = await fetchHtml(`https://en.porndiff.com/search/?q=${encodeURIComponent(query)}`, 14e3);
	if (!html) return null;
	const hits = parsePorndiffSearch(html);
	if (!hits.length) return null;
	const best = pickBestMatch(hits, query, (h) => h.title, (h) => `${h.slug.replace(/-/g, " ")} ${h.performers.join(" ")}`);
	if (!best) return null;
	const extra = await enrichPorndiff(best.item);
	const coverUrl = await firstVerified(extra.coverCandidates);
	if (!coverUrl) return {
		...empty("unverified"),
		title: extra.title,
		source: "porndiff"
	};
	return {
		coverUrl,
		title: extra.title,
		studio: extra.studio,
		source: "porndiff",
		performers: best.item.performers,
		pageUrl: best.item.pageUrl
	};
}
function psmcdnFromPage(html) {
	const og = attr(html, "og:image");
	const raw = og ? unwrapPsmcdn(og) : null;
	const direct = html.match(/https:\/\/images\.psmcdn\.net\/(?:cdn-cgi\/image\/[^/]+\/)?teamskeet\/[a-z]+\/[a-z0-9_]+\/shared\/(?:hi|med)\.jpg/i)?.[0] ?? null;
	const url = raw || (direct ? unwrapPsmcdn(direct) : null);
	return url ? preferHiJpg(url) : null;
}
function studioFromPsmcdn(url) {
	const m = url.match(/\/teamskeet\/([a-z]+)\//i);
	return m ? CODE_STUDIO[m[1]] ?? null : null;
}
async function lookupTeamSkeetPage(url, query) {
	const html = await fetchHtml(url, 1e4);
	if (!html) return null;
	const title = (attr(html, "og:title") || decodeHtml((html.match(/<title>([^<]+)<\/title>/i)?.[1] ?? "").split("|")[0] ?? "")).replace(/\s+\|\s+.*$/, "").trim();
	if (!title) return null;
	if (!isStrongMatch(query, title).ok) return null;
	const cover = psmcdnFromPage(html);
	if (!cover) return null;
	const hi = await verifyImage(cover);
	const med = hi ? hi : await verifyImage(cover.replace("/shared/hi.jpg", "/shared/med.jpg"));
	if (!med) return null;
	const performers = [...html.matchAll(/Starring\s+([^<]+)/i)].map((x) => decodeHtml(x[1].trim())).filter(Boolean);
	return {
		coverUrl: med,
		title,
		studio: studioFromPsmcdn(med),
		source: "teamskeet",
		performers,
		pageUrl: url
	};
}
async function searchTeamSkeet(query) {
	const slugs = slugifyTitle(query);
	const studios = detectStudios(query);
	const hubUrls = [...new Set(slugs.map((slug) => `https://www.teamskeet.com/movies/${slug}`))];
	for (const batch of [hubUrls]) {
		const hit = (await Promise.all(batch.map((u) => lookupTeamSkeetPage(u, query)))).find((r) => r?.coverUrl);
		if (hit) return hit;
	}
	const studioUrls = [];
	const hosts = studios.length ? studios.map((s) => s.host).filter((h) => Boolean(h)) : STUDIO_ALIASES.map((s) => s.host).filter((h) => Boolean(h));
	for (const slug of slugs) for (const host of hosts) studioUrls.push(`https://${host}/movies/${slug}`);
	const uniqueStudio = [...new Set(studioUrls)].slice(0, 10);
	return (await Promise.all(uniqueStudio.map((u) => lookupTeamSkeetPage(u, query)))).find((r) => r?.coverUrl) ?? null;
}
function thenudeFull(url) {
	return url.trim().replace(/ /g, "%20").replace("/thumbs/", "/").replace("/medheads/", "/");
}
function parseThenudeListing(html, studioName) {
	const items = [];
	const re = /src="(https:\/\/static\.thenude\.com\/admin\/covers\/[^"]+)"[^>]*alt="([^"]+)"/g;
	const re2 = /alt="([^"]+)"[^>]*src="(https:\/\/static\.thenude\.com\/admin\/covers\/[^"]+)"/g;
	let m;
	while (m = re.exec(html)) items.push({
		image: thenudeFull(m[1]),
		title: decodeHtml(m[2])
	});
	while (m = re2.exec(html)) items.push({
		image: thenudeFull(m[2]),
		title: decodeHtml(m[1])
	});
	return items.map((it) => ({
		...it,
		title: it.title.replace(/\s+video from .+$/i, "").replace(/\s+gallery from .+$/i, "").replace(new RegExp(`\\s+from ${studioName}$`, "i"), "").replace(/\s+in\s+/i, " ").trim()
	}));
}
async function searchThenude(query) {
	const targets = detectStudios(query).map((s) => s.thenude).filter((x) => Boolean(x));
	if (!targets.length) {
		if (/\bbrazzers\b/i.test(query)) targets.push("brazzers");
		if (/nubiles|teach sex/i.test(query)) targets.push("momsteachsex", "nubiles");
		if (/bratty/i.test(query)) targets.push("brattysis");
	}
	if (!targets.length) return null;
	for (const site of [...new Set(targets)].slice(0, 3)) {
		const html = await fetchHtml(`https://www.thenude.com/covers/${site}/`, 12e3);
		if (!html) continue;
		const studioName = STUDIO_ALIASES.find((s) => s.thenude === site)?.name ?? site;
		const best = pickBestMatch(parseThenudeListing(html, studioName), query, (it) => it.title);
		if (!best) continue;
		const coverUrl = await firstVerified([best.item.image]);
		if (!coverUrl) continue;
		return {
			coverUrl,
			title: best.item.title,
			studio: studioName,
			source: "thenude",
			performers: [],
			pageUrl: `https://www.thenude.com/covers/${site}/`
		};
	}
	return null;
}
async function searchBrattyFamily(query) {
	if (!/bratty/i.test(query) && !detectStudios(query).some((s) => s.thenude === "brattysis")) return null;
	const html = await fetchHtml(`https://www.brattyfamily.com/?s=${encodeURIComponent(query)}`, 1e4);
	if (!html) return null;
	const items = [];
	const re = /<a[^>]+href="(https:\/\/(?:www\.)?brattyfamily\.com\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
	let m;
	while (m = re.exec(html)) {
		const pageUrl = m[1];
		const inner = m[2];
		const title = decodeHtml(inner.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
		const img = inner.match(/https:\/\/(?:www\.)?brattyfamily\.com\/wp-content\/uploads\/[^"'\s]+/i);
		if (title && img) items.push({
			title,
			image: img[0],
			pageUrl
		});
	}
	const best = pickBestMatch(items, query, (it) => it.title);
	if (!best) return null;
	const coverUrl = await firstVerified([best.item.image]);
	if (!coverUrl) return null;
	return {
		coverUrl,
		title: best.item.title,
		studio: "Bratty Sis",
		source: "brattysis",
		performers: [],
		pageUrl: best.item.pageUrl
	};
}
async function findCover(rawQuery) {
	const query = rawQuery.replace(/\s+/g, " ").trim();
	if (query.length < 2) return empty("invalid_query");
	const primary = await searchPorndiff(query);
	if (primary?.coverUrl) return primary;
	const skeet = await searchTeamSkeet(query);
	if (skeet?.coverUrl) return skeet;
	const nude = await searchThenude(query);
	if (nude?.coverUrl) return nude;
	const bratty = await searchBrattyFamily(query);
	if (bratty?.coverUrl) return bratty;
	return empty("not_found");
}
var Route$1 = createFileRoute("/api/cover")({ server: { handlers: {
	GET: async ({ request }) => {
		const result = await findCover(new URL(request.url).searchParams.get("q") ?? "");
		const status = result.coverUrl ? 200 : result.error === "invalid_query" ? 400 : 404;
		return Response.json(result, { status });
	},
	POST: async ({ request }) => {
		let q = "";
		try {
			const body = await request.json();
			q = String(body.q ?? body.query ?? "");
		} catch {
			q = "";
		}
		const result = await findCover(q);
		const status = result.coverUrl ? 200 : result.error === "invalid_query" ? 400 : 404;
		return Response.json(result, { status });
	}
} } });
var Route = createFileRoute("/api/image")({ server: { handlers: { GET: async ({ request }) => {
	const raw = new URL(request.url).searchParams.get("url") ?? "";
	if (!isAllowedImageUrl(raw)) return new Response("Forbidden", { status: 403 });
	try {
		const upstream = await fetch(raw, {
			headers: {
				...FETCH_HEADERS,
				Accept: "image/jpeg,image/png,image/webp,image/*;q=0.8"
			},
			redirect: "follow",
			signal: AbortSignal.timeout(12e3)
		});
		if (!upstream.ok) return new Response("Not found", { status: 404 });
		const ct = upstream.headers.get("content-type") || "image/jpeg";
		if (!ct.startsWith("image/")) return new Response("Not an image", { status: 415 });
		return new Response(upstream.body, {
			status: 200,
			headers: {
				"content-type": ct,
				"cache-control": "public, max-age=86400"
			}
		});
	} catch {
		return new Response("Upstream error", { status: 502 });
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	ApiCoverRoute: Route$1.update({
		id: "/api/cover",
		path: "/api/cover",
		getParentRoute: () => Route$3
	}),
	ApiImageRoute: Route.update({
		id: "/api/image",
		path: "/api/image",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getRouter, router_Dbdt380v_exports as t };
